package rpg;

import rpg.entities.Game;

public class Main {
    public static void main(String[] args) {
        Game game = new Game();
        game.startGame();  // Cambiar start() por startGame()
    }
}
