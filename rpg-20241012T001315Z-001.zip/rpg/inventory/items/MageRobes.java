package rpg.inventory.items;

public class MageRobes extends Armor {

    public MageRobes() {
        super("Túnica de Mago", 3,5);
    }
}
