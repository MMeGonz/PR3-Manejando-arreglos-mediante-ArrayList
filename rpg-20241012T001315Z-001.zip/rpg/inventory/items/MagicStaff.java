package rpg.inventory.items;

public class MagicStaff extends Weapon {

    public MagicStaff() {
        super("Bastón Mágico", 18,10);
    }
}
