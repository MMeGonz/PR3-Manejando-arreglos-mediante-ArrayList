package rpg.inventory.items;

public class Shield extends Armor {

    public Shield() {
        super("Escudo", 8,10);
    }
}
