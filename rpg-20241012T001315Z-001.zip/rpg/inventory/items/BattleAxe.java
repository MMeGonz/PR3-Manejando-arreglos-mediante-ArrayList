package rpg.inventory.items;

public class BattleAxe extends Weapon {

    public BattleAxe() {
        super("Hacha de Batalla", 15,10);
    }
}
