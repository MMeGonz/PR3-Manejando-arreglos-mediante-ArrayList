package rpg.inventory.items;

public class ChainMail extends Armor {

    public ChainMail() {
        super("Cota de Malla", 10,15);
    }
}
