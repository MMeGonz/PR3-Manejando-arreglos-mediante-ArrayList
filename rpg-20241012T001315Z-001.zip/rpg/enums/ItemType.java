package rpg.enums;

public enum ItemType {
    MISC,       // Ítems misceláneos
    ARMOR,      // Armaduras
    WEAPON ,    // Armas
}
