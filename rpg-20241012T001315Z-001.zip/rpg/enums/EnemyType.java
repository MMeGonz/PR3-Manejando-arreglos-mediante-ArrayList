package rpg.enums;

public enum EnemyType {
    BASIC,      // Enemigo común
    RARE,       // Enemigo raro
    BOSS,       // Enemigo jefe
    SECRET      // Enemigo secreto
}
